self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "55743877f3ffd5fc834e97bc43a6e7bd",
    "url": "/config.json"
  },
  {
    "revision": "73a30b6ff9b7b50ab31d",
    "url": "/css/app.52397046.css"
  },
  {
    "revision": "6be723e085e983066b9d",
    "url": "/css/chunk-vendors.2c2aaac6.css"
  },
  {
    "revision": "015400679694f1f51047e46da0e1dc98",
    "url": "/fonts/materialdesignicons-webfont.01540067.ttf"
  },
  {
    "revision": "3dbd69ce25ff6cc0beeab5e798a6624e",
    "url": "/fonts/materialdesignicons-webfont.3dbd69ce.woff2"
  },
  {
    "revision": "4f8c18bc697174f623b12238cd068c1e",
    "url": "/fonts/materialdesignicons-webfont.4f8c18bc.woff"
  },
  {
    "revision": "fbc507ecfa138f295958a7578a393ced",
    "url": "/fonts/materialdesignicons-webfont.fbc507ec.eot"
  },
  {
    "revision": "3abd8a68dc5c20d00d1ab8def9723404",
    "url": "/fonts/roboto-black.woff2"
  },
  {
    "revision": "a59072f933169d3f2db497f44ca4cbbe",
    "url": "/fonts/roboto-bold.woff2"
  },
  {
    "revision": "5591b62beff3a20beaedd6cace4c6520",
    "url": "/fonts/roboto-light.woff2"
  },
  {
    "revision": "07db243db21ed0a6b4ff05ff429686b7",
    "url": "/fonts/roboto-medium.woff2"
  },
  {
    "revision": "15fa3062f8929bd3b05fdca5259db412",
    "url": "/fonts/roboto-regular.woff2"
  },
  {
    "revision": "d0151dbc1398a43954bb2b089a80826f",
    "url": "/fonts/roboto-thin.woff2"
  },
  {
    "revision": "8b8dca3bdd1ed898172885f1592d57c1",
    "url": "/fonts/robotoMono-regular.woff"
  },
  {
    "revision": "770f1bccee1735cf29cb82ced9aea9de",
    "url": "/img/klipper.svg"
  },
  {
    "revision": "5b493fc130bcd437e8312ee77e91e267",
    "url": "/img/logo.svg"
  },
  {
    "revision": "781c9c5bf86c78cc57a1f7648238b856",
    "url": "/img/sidebar-background.svg"
  },
  {
    "revision": "a971c291913d0105256b327143d886f5",
    "url": "/index.html"
  },
  {
    "revision": "73a30b6ff9b7b50ab31d",
    "url": "/js/app.be4c8895.js"
  },
  {
    "revision": "6be723e085e983066b9d",
    "url": "/js/chunk-vendors.cdcfe341.js"
  },
  {
    "revision": "cccb84463c222de77b76c3f3e2f8cf86",
    "url": "/manifest.json"
  }
]);